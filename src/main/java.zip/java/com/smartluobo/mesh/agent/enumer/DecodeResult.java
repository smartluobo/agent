package com.smartluobo.mesh.agent.enumer;

public enum DecodeResult {
    NEED_MORE_INPUT,
    SKIP_INPUT
}
